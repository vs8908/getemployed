function populate(quiz) {
    debugger;
    if(quiz.isEnded()) {
        showScores(quiz);
    }
    else {
        // show question
        var element = document.getElementById("question");
        element.innerHTML = quiz.getQuestionIndex().text;

        // show options
        var choices = quiz.getQuestionIndex().choices;
        for(var i = 0; i < choices.length; i++) {
            var element = document.getElementById("choice" + i);
            element.innerHTML = choices[i];
            guess("btn" + i, choices[i], quiz);
        }

        showProgress(quiz);
    }
};

function guess(id, guess, quiz) {
    var button = document.getElementById(id);
    button.onclick = function() {
        quiz.guess(guess);
        populate(quiz);
    }
};


function showProgress(quiz) {
    var currentQuestionNumber = quiz.questionIndex + 1;
    var element = document.getElementById("progress");
    element.innerHTML = "Question " + currentQuestionNumber + " of " + quiz.questions.length;
};

function showScores(quiz) {
    var gameOverHTML = "<h1>Result</h1>";
    gameOverHTML += "<h2 id='score'> Your scores: " + quiz.score + "</h2>";
    var element = document.getElementById("quiz");
    element.innerHTML = gameOverHTML;
};

// create questions
var questions = [
    new Question("Which one is not an object oriented programming language?", ["Java", "C#","C++", "C"], "C"),
    new Question("Which language is used for styling web pages?", ["HTML", "JQuery", "CSS", "XML"], "CSS"),
    new Question("There are ____ main components of object oriented programming.", ["1", "6","2", "4"], "4"),
    new Question("Which language is used for web apps?", ["PHP", "Python", "Javascript", "All"], "All"),
    new Question("MVC is a ____.", ["Language", "Library", "Framework", "All"], "Framework"),

    new Question("1+2=?", ["3", "4", "5", "6"], "6"),
    new Question("1+2=?", ["3", "4", "5", "6"], "6"),
    new Question("1+2=?", ["3", "4", "5", "6"], "6"),
    new Question("1+2=?", ["3", "4", "5", "6"], "6"),
    new Question("1+2=?", ["3", "4", "5", "6"], "6"),
    new Question("1+2=?", ["3", "4", "5", "6"], "6")
];

// create quiz
var quiz = new Quiz(questions);

// display quiz
populate(quiz);





